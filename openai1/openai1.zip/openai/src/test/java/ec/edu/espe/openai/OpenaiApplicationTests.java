package ec.edu.espe.openai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenaiApplicationTests {

	@Test
	void contextLoads() {
	}

}
